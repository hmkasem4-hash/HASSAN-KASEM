import { CourtCase } from '../types';

// Arabic Hijri month names in Umm al-Qura
export const HIJRI_MONTHS = [
  'محرم',
  'صفر',
  'ربيع الأول',
  'ربيع الآخر',
  'جمادى الأولى',
  'جمادى الآخرة',
  'رجب',
  'شعبان',
  'رمضان',
  'شوال',
  'ذو القعدة',
  'ذو الحجة',
];

export const GREGORIAN_MONTHS = [
  'يناير',
  'فبراير',
  'مارس',
  'أبريل',
  'مايو',
  'يونيو',
  'يوليو',
  'أغسطس',
  'سبتمبر',
  'أكتوبر',
  'نوفمبر',
  'ديسمبر',
];

/**
 * Convert Eastern Arabic numerals (٠-٩) to Latin digits (0-9)
 */
export function easternToLatinDigits(str: string): string {
  const eastern = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
  return str.replace(/[٠-٩]/g, (w) => eastern.indexOf(w).toString());
}

/**
 * Convert Latin digits (0-9) to Eastern Arabic numerals (٠-٩)
 */
export function latinToEasternDigits(num: number | string): string {
  const str = String(num);
  const eastern = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
  return str.replace(/[0-9]/g, (w) => eastern[parseInt(w, 10)]);
}

/**
 * Parse YYYY-MM-DD string into a safe Date object
 */
export function parseDateString(dateStr: string): Date {
  const [year, month, day] = dateStr.split('-').map(Number);
  return new Date(year, (month || 1) - 1, day || 1);
}

/**
 * Format a Date or date string into Umm al-Qura (تقويم أم القرى) Hijri string.
 * Example: "3 صفر 1448 هـ" or "الخميس، 3 صفر 1448 هـ"
 */
export function formatHijriDate(
  dateInput: string | Date,
  options?: {
    includeWeekday?: boolean;
    useEasternDigits?: boolean;
    includeEra?: boolean;
  }
): string {
  try {
    const date = typeof dateInput === 'string' ? parseDateString(dateInput) : dateInput;
    if (isNaN(date.getTime())) return '';

    const { includeWeekday = false, useEasternDigits = false, includeEra = true } = options || {};

    const intlFormatter = new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura', {
      weekday: includeWeekday ? 'long' : undefined,
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });

    let formatted = intlFormatter.format(date);

    if (!useEasternDigits) {
      formatted = easternToLatinDigits(formatted);
    }

    if (includeEra && !formatted.includes('هـ')) {
      formatted += ' هـ';
    }

    return formatted;
  } catch (e) {
    console.warn('Error formatting Hijri date with Umm al-Qura:', e);
    return '';
  }
}

/**
 * Extract parsed Umm al-Qura parts (day, monthName, year)
 */
export function getHijriDateParts(dateInput: string | Date): {
  day: number;
  dayEastern: string;
  monthName: string;
  year: number;
  yearEastern: string;
  formatted: string;
  isFirstDayOfMonth: boolean;
} {
  try {
    const date = typeof dateInput === 'string' ? parseDateString(dateInput) : dateInput;
    const partsFormatter = new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });

    const parts = partsFormatter.formatToParts(date);
    let dayStr = '1';
    let monthName = '';
    let yearStr = '1448';

    for (const p of parts) {
      if (p.type === 'day') dayStr = easternToLatinDigits(p.value);
      if (p.type === 'month') monthName = p.value;
      if (p.type === 'year') yearStr = easternToLatinDigits(p.value);
    }

    const day = parseInt(dayStr, 10) || 1;
    const year = parseInt(yearStr, 10) || 1448;

    return {
      day,
      dayEastern: latinToEasternDigits(day),
      monthName,
      year,
      yearEastern: latinToEasternDigits(year),
      formatted: `${day} ${monthName} ${year} هـ`,
      isFirstDayOfMonth: day === 1,
    };
  } catch {
    return {
      day: 1,
      dayEastern: '١',
      monthName: '',
      year: 1448,
      yearEastern: '١٤٤٨',
      formatted: '',
      isFirstDayOfMonth: false,
    };
  }
}

/**
 * Format a Date or ISO string into a rich Arabic Gregorian string.
 * Example: "الخميس، 16 أغسطس 2026 م"
 */
export function formatArabicDate(
  dateStr: string,
  options?: { includeWeekday?: boolean; includeEra?: boolean }
): string {
  try {
    const date = parseDateString(dateStr);
    const { includeWeekday = true, includeEra = true } = options || {};

    const formatted = date.toLocaleDateString('ar-EG', {
      weekday: includeWeekday ? 'long' : undefined,
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });

    const withLatinDigits = easternToLatinDigits(formatted);
    return includeEra ? `${withLatinDigits} م` : withLatinDigits;
  } catch {
    return dateStr;
  }
}

/**
 * Get Dual Date Representation: Gregorian + Umm al-Qura Hijri
 * Example: "16 أغسطس 2026 م (3 صفر 1448 هـ)"
 */
export function formatDualDate(
  dateStr: string,
  options?: {
    includeWeekday?: boolean;
    compact?: boolean;
  }
): string {
  try {
    const gregorian = formatArabicDate(dateStr, {
      includeWeekday: options?.includeWeekday,
      includeEra: true,
    });
    const hijri = formatHijriDate(dateStr, {
      includeWeekday: false,
      useEasternDigits: false,
      includeEra: true,
    });

    if (options?.compact) {
      return `${gregorian} • ${hijri}`;
    }

    return `${gregorian} الموافق ${hijri} (أم القرى)`;
  } catch {
    return dateStr;
  }
}

/**
 * Format time in 12-hour Arabic format.
 * Example: "09:30 ص" or "02:15 م"
 */
export function formatArabicTime(timeStr?: string): string {
  if (!timeStr) return '09:00 ص';
  const [hoursStr, minutesStr] = timeStr.split(':');
  let hours = parseInt(hoursStr, 10);
  const minutes = minutesStr || '00';
  const period = hours >= 12 ? 'م' : 'ص';
  if (hours > 12) hours -= 12;
  if (hours === 0) hours = 12;
  return `${hours.toString().padStart(2, '0')}:${minutes} ${period}`;
}

/**
 * Get date object from sessionDate (YYYY-MM-DD) and sessionTime (HH:mm)
 */
export function getSessionDateTime(sessionDate: string, sessionTime?: string): Date {
  const [y, m, d] = sessionDate.split('-').map(Number);
  let hours = 9;
  let mins = 0;
  if (sessionTime) {
    const [h, min] = sessionTime.split(':').map(Number);
    if (!isNaN(h)) hours = h;
    if (!isNaN(min)) mins = min;
  }
  return new Date(y, (m || 1) - 1, d || 1, hours, mins, 0);
}

/**
 * Calculate difference in hours between now and session date/time
 */
export function getHoursRemaining(sessionDate: string, sessionTime?: string): number {
  const now = new Date();
  const sessionDt = getSessionDateTime(sessionDate, sessionTime);
  const diffMs = sessionDt.getTime() - now.getTime();
  return diffMs / (1000 * 60 * 60);
}

/**
 * Check if session is within the next 24 hours (and hasn't passed more than 3 hours ago)
 */
export function isWithin24Hours(c: CourtCase): boolean {
  if (c.status === 'judged' || c.status === 'struck_off') return false;
  const hours = getHoursRemaining(c.sessionDate, c.sessionTime);
  return hours > -3 && hours <= 24;
}

/**
 * Check if session is today
 */
export function isToday(sessionDate: string): boolean {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  const todayStr = `${y}-${m}-${d}`;
  return sessionDate === todayStr;
}

/**
 * Check if session is tomorrow
 */
export function isTomorrow(sessionDate: string): boolean {
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const y = tomorrow.getFullYear();
  const m = String(tomorrow.getMonth() + 1).padStart(2, '0');
  const d = String(tomorrow.getDate()).padStart(2, '0');
  const tomorrowStr = `${y}-${m}-${d}`;
  return sessionDate === tomorrowStr;
}

/**
 * Get humanized countdown text in Arabic
 */
export function getCountdownBadge(sessionDate: string, sessionTime?: string): {
  text: string;
  isUrgent: boolean;
  colorClass: string;
} {
  const hours = getHoursRemaining(sessionDate, sessionTime);

  if (hours < -4) {
    return {
      text: 'انتهى موعد الجلسة',
      isUrgent: false,
      colorClass: 'bg-slate-100 text-slate-600 border-slate-200',
    };
  }

  if (hours < 0) {
    return {
      text: 'الجلسة جارية الآن / اليوم',
      isUrgent: true,
      colorClass: 'bg-rose-50 text-rose-700 border-rose-200 animate-pulse',
    };
  }

  if (hours <= 24) {
    const totalMinutes = Math.floor(hours * 60);
    const h = Math.floor(totalMinutes / 60);
    const m = totalMinutes % 60;
    
    let timeStr = '';
    if (h > 0 && m > 0) {
      timeStr = `${h} س و ${m} د`;
    } else if (h > 0) {
      timeStr = `${h} ساعة`;
    } else {
      timeStr = `${m} دقيقة`;
    }

    return {
      text: `متبقي ${timeStr} ⚠️ (أقل من 24 س)`,
      isUrgent: true,
      colorClass: 'bg-amber-50 text-amber-800 border-amber-300 ring-1 ring-amber-400/40 animate-pulse',
    };
  }

  if (isTomorrow(sessionDate)) {
    return {
      text: 'غداً',
      isUrgent: false,
      colorClass: 'bg-sky-50 text-sky-700 border-sky-200',
    };
  }

  const days = Math.ceil(hours / 24);
  if (days <= 7) {
    return {
      text: `بعد ${days} أيام`,
      isUrgent: false,
      colorClass: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    };
  }

  return {
    text: `بعد ${days} يوم`,
    isUrgent: false,
    colorClass: 'bg-slate-50 text-slate-600 border-slate-200',
  };
}

/**
 * Get date relative string for today / tomorrow with dual date
 */
export function getRelativeDayName(dateStr: string): string {
  const hijri = formatHijriDate(dateStr, { includeWeekday: false });
  if (isToday(dateStr)) return `اليوم (${hijri})`;
  if (isTomorrow(dateStr)) return `غداً (${hijri})`;
  return formatDualDate(dateStr, { includeWeekday: true });
}

/**
 * Get current date string in YYYY-MM-DD format
 */
export function getTodayString(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

/**
 * Add days to date string
 */
export function addDaysToDate(dateStr: string, days: number): string {
  const [y, m, d] = dateStr.split('-').map(Number);
  const date = new Date(y, (m || 1) - 1, d || 1);
  date.setDate(date.getDate() + days);
  const resY = date.getFullYear();
  const resM = String(date.getMonth() + 1).padStart(2, '0');
  const resD = String(date.getDate()).padStart(2, '0');
  return `${resY}-${resM}-${resD}`;
}

