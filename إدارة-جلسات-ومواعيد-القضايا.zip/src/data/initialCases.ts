import { CourtCase } from '../types';
import { getTodayString, addDaysToDate } from '../utils/dateUtils';

const today = getTodayString();
const tomorrow = addDaysToDate(today, 1);
const in3Days = addDaysToDate(today, 3);
const in5Days = addDaysToDate(today, 5);
const in10Days = addDaysToDate(today, 10);
const pastWeek = addDaysToDate(today, -7);

export const INITIAL_CASES: CourtCase[] = [
  {
    id: 'case-101',
    caseNumber: '1428',
    caseYear: '2025',
    court: 'المحكمة الاقتصادية',
    circuit: 'الدائرة 3 استئنافي',
    judge: 'المستشار / أحمد فهمي',
    title: 'دعوى تعويض عن إخلال بعقد توريد برمجيات وعلامة تجارية',
    clientName: 'شركة النور للحلول الرقمية',
    clientRole: 'مدعي',
    clientPhone: '01012345678',
    opponentName: 'مؤسسة الأفق للتجارة والتوزيع',
    opponentLawyer: 'الأستاذ / سامح عبد الرحمن',
    assignedLawyer: 'الأستاذ / أحمد الشريف',
    sessionDate: today,
    sessionTime: '10:00',
    sessionStage: 'مرافعة وتقديم مذكرات',
    status: 'active',
    previousDecision: 'التأجيل لجلسة اليوم لتبادل المذكرات الختامية وتقديم أصل العقد الموثق',
    demands: 'تقديم مذكرة الدفاع الختامية وحافظة مستندات تتضمن تقرير الخبير الفني',
    notes: 'التأكيد على تسليم المذكرة المنسوخة لسكرتير الجلسة قبل الساعة 10:30 صباحاً',
    remind24h: true,
    priority: 'urgent',
    checklist: [
      { id: 'chk-1', text: 'طباعة 3 نسخ من مذكرة الدفاع الختامية', completed: true },
      { id: 'chk-2', text: 'أصل التوكيل وصورة كارنيه المحاماة', completed: true },
      { id: 'chk-3', text: 'حافظة المستندات مطوية ومصنفة (تقرير الخبير)', completed: false },
      { id: 'chk-4', text: 'سداد رسم الإيداع وتجهيز الإيصال', completed: false }
    ],
    history: [
      {
        id: 'hist-1',
        date: pastWeek,
        decision: 'تأجيل لورود تقرير الخبير الحسابي مع التصريح باستخراج صورة طبق الأصل',
        reason: 'عدم ورود التقرير في الموعد المحدد',
        notes: 'تم التواصل مع مكتب الخبراء وتم استلام التقرير رسمياً',
        createdAt: pastWeek
      }
    ],
    createdAt: today,
    updatedAt: today
  },
  {
    id: 'case-102',
    caseNumber: '584',
    caseYear: '2026',
    court: 'محكمة الأسرة',
    circuit: 'دائرة 5 أسرة مدينة نصر',
    judge: 'المستشار / طارق محمود',
    title: 'دعوى نفقة زوجية وصغار وأجر مسكن وحضانة',
    clientName: 'أ / فاطمة الزهراء إبراهيم',
    clientRole: 'مدعي',
    clientPhone: '01198765432',
    opponentName: 'خالد مصطفى حسن',
    opponentLawyer: 'الأستاذ / محمود شاكر',
    assignedLawyer: 'الأستاذة / سارة المنصور',
    sessionDate: tomorrow,
    sessionTime: '09:30',
    sessionStage: 'استجواب وسماع شهود',
    status: 'active',
    previousDecision: 'تأجيل لسماع شهود الإثبات حول دخل المدعى عليه الشهري والأرباح التجارية',
    demands: 'حضور شاهدي الإثبات (الجار وزميل العمل) وإثبات التحريات الضريبية للزوج',
    notes: 'إحضار شهادات الميلاد الأصلية للأطفال وإفادة بالراتب من جهة العمل',
    remind24h: true,
    priority: 'urgent',
    checklist: [
      { id: 'chk-10', text: 'التأكيد على حضور الشاهدين في التاسعة صباحاً', completed: true },
      { id: 'chk-11', text: 'تجهيز أصل مفردات المرتب والتحري عن الدخل', completed: true },
      { id: 'chk-12', text: 'صورة وثيقة الزواج وشهادات ميلاد الصغار', completed: true }
    ],
    history: [
      {
        id: 'hist-2',
        date: pastWeek,
        decision: 'إحالة الدعوى للتحقيق لإثبات دخل المدعى عليه بالشهود',
        reason: 'إنكار المدعى عليه لقيمة الدخل الحقيقي',
        notes: 'تم التجهيز مع الموكلة والشهود',
        createdAt: pastWeek
      }
    ],
    createdAt: today,
    updatedAt: today
  },
  {
    id: 'case-103',
    caseNumber: '3120',
    caseYear: '2024',
    court: 'محكمة الاستئناف',
    circuit: 'الدائرة 14 مدني عالي',
    judge: 'المستشار / حسام الدين الجزار',
    title: 'استئناف حكم صحة ونفاذ عقد بيع عقار سكني بالتجمع',
    clientName: 'المهندس / هشام كمال الدين',
    clientRole: 'مستأنف',
    clientPhone: '01223344556',
    opponentName: 'شركة الإعمار للتطوير العقاري',
    opponentLawyer: 'الأستاذة / نورهان الشناوي',
    assignedLawyer: 'الأستاذ / محمد القحطاني',
    sessionDate: in3Days,
    sessionTime: '11:00',
    sessionStage: 'حجز للحكم',
    status: 'active',
    previousDecision: 'حجز الاستئناف للحكم مع التصريح بمذكرات خلال أسبوعين',
    demands: 'متابعة صدور الحكم أو مد الأجل وتدوين المنطوق فور نطقه',
    notes: 'طلب شهادة بمنطوق الحكم فور النطق به تمهيداً للتسجيل بالشهر العقاري',
    remind24h: true,
    priority: 'high',
    checklist: [
      { id: 'chk-20', text: 'تجهيز نموذج استخراج شهادة بالجدول', completed: false },
      { id: 'chk-21', text: 'مراجعة المذكرة الختامية المودعة', completed: true }
    ],
    history: [],
    createdAt: today,
    updatedAt: today
  },
  {
    id: 'case-104',
    caseNumber: '9211',
    caseYear: '2025',
    court: 'مجلس الدولة / القضاء الإداري',
    circuit: 'الدائرة الأولى أفراد وحقوق',
    judge: 'المستشار / د. سعيد البنا',
    title: 'دعوى إلغاء قرار إداري بامتناع جهة الإدارة عن صرف مستحقات ترقية',
    clientName: 'د. يوسف عبد العزيز المنصوري',
    clientRole: 'طاعن',
    clientPhone: '01004455667',
    opponentName: 'وزارة التعليم العالي بصفتها',
    opponentLawyer: 'هيئة قضايا الدولة',
    assignedLawyer: 'الأستاذ / أحمد الشريف',
    sessionDate: in5Days,
    sessionTime: '10:30',
    sessionStage: 'تقديم مستندات ومذكرات',
    status: 'active',
    previousDecision: 'تأجيل لضم الملف الوظيفي وسداد أمانة الخبير',
    demands: 'إيداع حافظة مستندات تشمل قرارات الترقية الصادرة للزملاء المماثلين',
    notes: 'تم استلام تقرير مفوضي الدولة وكان الرأي لصالحنا بإلغاء القرار الإداري',
    remind24h: true,
    priority: 'normal',
    checklist: [
      { id: 'chk-30', text: 'نسخ تقرير هيئة مفوضي الدولة وتفنيد الدفوع', completed: true },
      { id: 'chk-31', text: 'استخراج صورة رسمية من قرار التعيين', completed: false }
    ],
    history: [],
    createdAt: today,
    updatedAt: today
  },
  {
    id: 'case-105',
    caseNumber: '765',
    caseYear: '2026',
    court: 'المحكمة العمالية',
    circuit: 'دائرة 2 عمال جنوب القاهرة',
    judge: 'المستشار / وجدي منصور',
    title: 'دعوى تعويض عن فصل تعسفي ومستحقات مكافأة نهاية الخدمة',
    clientName: 'أ / إبراهيم خليل مرسي',
    clientRole: 'مدعي',
    clientPhone: '01556677889',
    opponentName: 'مستشفى الشفاء التخصصي',
    opponentLawyer: 'الأستاذ / محمد حلمي',
    assignedLawyer: 'الأستاذ / خالد السعيد',
    sessionDate: in10Days,
    sessionTime: '09:00',
    sessionStage: 'تقرير الخبير',
    status: 'postponed',
    previousDecision: 'التأجيل لورود تقرير مكتب خبراء وزارة العدل في شأن حساب المقابل المالي لرصيد الإجازات',
    demands: 'الاستعلام عن ورود التقرير في قلم كتاب المحكمة قبل الجلسة',
    notes: 'تم سداد أمانة الخبير البالغة 1000 جنيه بالإيصال رقم 8872',
    remind24h: true,
    priority: 'normal',
    checklist: [
      { id: 'chk-40', text: 'الذهاب لمكتب الخبراء للاطلاع على المسودة', completed: false }
    ],
    history: [
      {
        id: 'hist-3',
        date: pastWeek,
        decision: 'إحالة لمكتب خبراء وزارة العدل لتقدير رصيد الإجازات وبدل الإنذار',
        reason: 'طلب دفاع المدعي بندب خبير حسابي وعمالي',
        notes: 'جلسة تمهيدية هامة',
        createdAt: pastWeek
      }
    ],
    createdAt: today,
    updatedAt: today
  }
];
