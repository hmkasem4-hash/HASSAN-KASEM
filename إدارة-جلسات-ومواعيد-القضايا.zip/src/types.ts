export type CourtType =
  | 'محكمة النقض'
  | 'محكمة الاستئناف'
  | 'المحكمة الابتدائية'
  | 'المحكمة الاقتصادية'
  | 'محكمة الأسرة'
  | 'مجلس الدولة / القضاء الإداري'
  | 'محكمة الجنايات'
  | 'محكمة الجنح'
  | 'المحكمة العمالية'
  | 'المحكمة التجارية'
  | 'أخرى';

export type SessionStage =
  | 'مرافعة'
  | 'تقديم مستندات ومذكرات'
  | 'استجواب وسماع شهود'
  | 'حجز للحكم'
  | 'نطق بالحكم'
  | 'تقرير الخبير'
  | 'الصلح والتسوية'
  | 'تجديد حبس'
  | 'إعادة إعلان'
  | 'أخرى';

export type CaseStatus =
  | 'active'      // سارية / قادمة
  | 'postponed'   // مؤجلة
  | 'judged'      // محكوم فيها / منتهية
  | 'struck_off'; // مشطوبة

export type ClientRole =
  | 'مدعي'
  | 'مدعى عليه'
  | 'مجني عليه'
  | 'متهم'
  | 'مستأنف'
  | 'مستأنف ضده'
  | 'طاعن'
  | 'مطعون ضده'
  | 'شاهد'
  | 'أخرى';

export interface PreparationChecklistItem {
  id: string;
  text: string;
  completed: boolean;
}

export interface SessionHistoryItem {
  id: string;
  date: string;
  decision: string;
  lawyer?: string;
  reason?: string;
  notes?: string;
  createdAt: string;
}

export interface CourtCase {
  id: string;
  caseNumber: string;         // رقم الدعوى / القضية
  caseYear: string;           // السنة القضائية
  court: CourtType | string;  // اسم المحكمة
  circuit: string;            // الدائرة / القاعة
  judge?: string;             // رئيس الدائرة / القاضي
  title: string;              // موضوع الدعوى / العنوان
  clientName: string;         // اسم الموكل
  clientRole: ClientRole;     // صفة الموكل
  clientPhone?: string;       // رقم هاتف الموكل
  opponentName: string;       // اسم الخصم
  opponentLawyer?: string;    // محامي الخصم
  assignedLawyer?: string;    // اسم المحامي الحاضر عن الموكل في الجلسة
  sessionDate: string;        // YYYY-MM-DD
  sessionTime: string;        // HH:mm
  sessionStage: SessionStage | string; // نوع أو مرحلة الجلسة
  status: CaseStatus;
  previousDecision?: string;  // القرار السابق
  demands?: string;           // المطلوب في الجلسة
  notes?: string;             // ملاحظات المحامي
  checklist: PreparationChecklistItem[]; // مهام وتجهيزات الجلسة
  remind24h: boolean;         // تنبيه قبل 24 ساعة
  history: SessionHistoryItem[]; // سجل الجلسات السابقة
  priority?: 'normal' | 'high' | 'urgent';
  createdAt: string;
  updatedAt: string;
}

export type ViewMode = 'cards' | 'table' | 'calendar' | 'timeline';

export type DateFilterType = 'all' | '24h' | 'today' | 'tomorrow' | 'this_week' | 'this_month' | 'past' | 'custom';
