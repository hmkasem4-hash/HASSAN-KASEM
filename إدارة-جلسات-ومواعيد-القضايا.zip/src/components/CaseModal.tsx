import React, { useState, useEffect } from 'react';
import { 
  X, 
  Building2, 
  Calendar, 
  Clock, 
  User, 
  Users, 
  UserCheck,
  FileText, 
  Bell, 
  Plus, 
  Trash2, 
  CheckSquare, 
  Check,
  Scale,
  Moon
} from 'lucide-react';
import { CourtCase, CourtType, SessionStage, ClientRole, PreparationChecklistItem } from '../types';
import { getTodayString, addDaysToDate, formatArabicDate, formatHijriDate } from '../utils/dateUtils';

interface CaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (caseData: Partial<CourtCase>) => void;
  initialData?: CourtCase | null;
  allCourts: string[];
}

const DEFAULT_COURTS: CourtType[] = [
  'المحكمة الابتدائية',
  'محكمة الاستئناف',
  'محكمة النقض',
  'المحكمة الاقتصادية',
  'محكمة الأسرة',
  'مجلس الدولة / القضاء الإداري',
  'محكمة الجنايات',
  'محكمة الجنح',
  'المحكمة العمالية',
  'المحكمة التجارية',
  'أخرى',
];

const STAGES: SessionStage[] = [
  'مرافعة',
  'تقديم مستندات ومذكرات',
  'استجواب وسماع شهود',
  'تقرير الخبير',
  'حجز للحكم',
  'نطق بالحكم',
  'إعادة إعلان',
  'الصلح والتسوية',
  'تجديد حبس',
  'أخرى',
];

const ROLES: ClientRole[] = [
  'مدعي',
  'مدعى عليه',
  'مستأنف',
  'مستأنف ضده',
  'طاعن',
  'مطعون ضده',
  'مجني عليه',
  'متهم',
  'أخرى',
];

const QUICK_CHECKLIST_PRESETS = [
  'إعداد وطباعة مذكرة الدفاع',
  'تجهيز حافظة المستندات',
  'أصل التوكيل وصورة الكارنيه',
  'سداد أمانة الخبير أو الرسوم',
  'التأكيد على حضور الموكل / الشهود',
  'إعلان الخصم بأصل الصحيفة',
  'استخراج شهادة من الجدول',
];

export const CaseModal: React.FC<CaseModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialData,
  allCourts,
}) => {
  const today = getTodayString();

  const [caseNumber, setCaseNumber] = useState('');
  const [caseYear, setCaseYear] = useState(new Date().getFullYear().toString());
  const [court, setCourt] = useState<string>('المحكمة الابتدائية');
  const [customCourt, setCustomCourt] = useState('');
  const [circuit, setCircuit] = useState('');
  const [judge, setJudge] = useState('');
  const [title, setTitle] = useState('');
  const [clientName, setClientName] = useState('');
  const [clientRole, setClientRole] = useState<ClientRole>('مدعي');
  const [clientPhone, setClientPhone] = useState('');
  const [opponentName, setOpponentName] = useState('');
  const [opponentLawyer, setOpponentLawyer] = useState('');
  const [assignedLawyer, setAssignedLawyer] = useState('الأستاذ / المحامي');
  const [sessionDate, setSessionDate] = useState(today);
  const [sessionTime, setSessionTime] = useState('09:30');
  const [sessionStage, setSessionStage] = useState<string>('مرافعة');
  const [previousDecision, setPreviousDecision] = useState('');
  const [demands, setDemands] = useState('');
  const [notes, setNotes] = useState('');
  const [remind24h, setRemind24h] = useState(true);
  const [checklist, setChecklist] = useState<PreparationChecklistItem[]>([]);
  const [newChecklistText, setNewChecklistText] = useState('');

  useEffect(() => {
    if (initialData) {
      setCaseNumber(initialData.caseNumber || '');
      setCaseYear(initialData.caseYear || new Date().getFullYear().toString());
      if (DEFAULT_COURTS.includes(initialData.court as CourtType)) {
        setCourt(initialData.court);
        setCustomCourt('');
      } else {
        setCourt('أخرى');
        setCustomCourt(initialData.court);
      }
      setCircuit(initialData.circuit || '');
      setJudge(initialData.judge || '');
      setTitle(initialData.title || '');
      setClientName(initialData.clientName || '');
      setClientRole(initialData.clientRole || 'مدعي');
      setClientPhone(initialData.clientPhone || '');
      setOpponentName(initialData.opponentName || '');
      setOpponentLawyer(initialData.opponentLawyer || '');
      setAssignedLawyer(initialData.assignedLawyer || 'الأستاذ / المحامي');
      setSessionDate(initialData.sessionDate || today);
      setSessionTime(initialData.sessionTime || '09:30');
      setSessionStage(initialData.sessionStage || 'مرافعة');
      setPreviousDecision(initialData.previousDecision || '');
      setDemands(initialData.demands || '');
      setNotes(initialData.notes || '');
      setRemind24h(initialData.remind24h ?? true);
      setChecklist(initialData.checklist || []);
    } else {
      // Reset defaults
      setCaseNumber('');
      setCaseYear(new Date().getFullYear().toString());
      setCourt('المحكمة الابتدائية');
      setCustomCourt('');
      setCircuit('الدائرة الأولى مدني');
      setJudge('');
      setTitle('');
      setClientName('');
      setClientRole('مدعي');
      setClientPhone('');
      setOpponentName('');
      setOpponentLawyer('');
      setAssignedLawyer('الأستاذ / المحامي');
      setSessionDate(today);
      setSessionTime('09:30');
      setSessionStage('مرافعة');
      setPreviousDecision('');
      setDemands('');
      setNotes('');
      setRemind24h(true);
      setChecklist([
        { id: '1', text: 'إعداد وطباعة مذكرة الدفاع', completed: false },
        { id: '2', text: 'تجهيز حافظة المستندات والتوكيل', completed: false }
      ]);
    }
  }, [initialData, isOpen, today]);

  if (!isOpen) return null;

  const handleAddChecklistItem = (text: string) => {
    if (!text.trim()) return;
    setChecklist([
      ...checklist,
      { id: Date.now().toString(), text: text.trim(), completed: false },
    ]);
    setNewChecklistText('');
  };

  const handleRemoveChecklistItem = (id: string) => {
    setChecklist(checklist.filter((item) => item.id !== id));
  };

  const handleToggleChecklist = (id: string) => {
    setChecklist(
      checklist.map((item) =>
        item.id === id ? { ...item, completed: !item.completed } : item
      )
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!caseNumber.trim() || !title.trim() || !clientName.trim()) {
      alert('يرجى ملء الحقول الإلزامية: رقم القضية، موضوع الدعوى، واسم الموكل.');
      return;
    }

    const finalCourt = court === 'أخرى' && customCourt.trim() ? customCourt.trim() : court;

    onSave({
      caseNumber: caseNumber.trim(),
      caseYear: caseYear.trim(),
      court: finalCourt,
      circuit: circuit.trim() || 'الدائرة الأولى',
      judge: judge.trim(),
      title: title.trim(),
      clientName: clientName.trim(),
      clientRole,
      clientPhone: clientPhone.trim(),
      opponentName: opponentName.trim() || 'غير محدد',
      opponentLawyer: opponentLawyer.trim(),
      assignedLawyer: assignedLawyer.trim(),
      sessionDate,
      sessionTime,
      sessionStage,
      previousDecision: previousDecision.trim(),
      demands: demands.trim(),
      notes: notes.trim(),
      remind24h,
      checklist,
      status: initialData?.status || 'active',
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 no-print animate-in fade-in">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-3xl w-full max-h-[92vh] flex flex-col overflow-hidden">
        
        {/* Modal Header */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between shrink-0 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-500 text-slate-950 rounded-xl font-bold">
              <Scale className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-extrabold text-white">
                {initialData ? 'تعديل بيانات القضية والجلسة' : 'إضافة قضية / جلسة جديدة'}
              </h2>
              <p className="text-xs text-slate-400">
                تسجيل بيانات المحكمة، الموكل، والخصم، وتفعيل التنبيهات الذكية
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Form */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-6">
          
          {/* Section 1: Court & Case Information */}
          <div className="space-y-4">
            <h3 className="text-xs font-black uppercase text-amber-700 tracking-wider flex items-center gap-2 border-b border-amber-100 pb-1">
              <Building2 className="w-4 h-4" />
              <span>بيانات المحكمة ورقم الدعوى</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  رقم القضية / الدعوى <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={caseNumber}
                  onChange={(e) => setCaseNumber(e.target.value)}
                  placeholder="مثال: 1428"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-sm font-mono focus:ring-2 focus:ring-amber-500 focus:bg-white transition"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  السنة القضائية
                </label>
                <input
                  type="text"
                  value={caseYear}
                  onChange={(e) => setCaseYear(e.target.value)}
                  placeholder="2026"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-sm font-mono focus:ring-2 focus:ring-amber-500 focus:bg-white transition"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  المحكمة المختصة <span className="text-rose-500">*</span>
                </label>
                <select
                  value={court}
                  onChange={(e) => setCourt(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-amber-500 focus:bg-white transition cursor-pointer"
                >
                  {DEFAULT_COURTS.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {court === 'أخرى' && (
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  اسم المحكمة المخصصة
                </label>
                <input
                  type="text"
                  value={customCourt}
                  onChange={(e) => setCustomCourt(e.target.value)}
                  placeholder="مثال: محكمة أسوان الابتدائية - مأمورية نصر النوبة"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-amber-500 focus:bg-white transition"
                />
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  الدائرة / القاعة
                </label>
                <input
                  type="text"
                  value={circuit}
                  onChange={(e) => setCircuit(e.target.value)}
                  placeholder="مثال: الدائرة 3 استئنافي عالي / قاعة 4"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-amber-500 focus:bg-white transition"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  رئيس الدائرة / القاضي (اختياري)
                </label>
                <input
                  type="text"
                  value={judge}
                  onChange={(e) => setJudge(e.target.value)}
                  placeholder="المستشار / ..."
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-amber-500 focus:bg-white transition"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                موضوع الدعوى / عنوان القضية <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="مثال: دعوى صحة ونفاذ عقد بيع عقار / دعوى بطلان قرار إداري"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-sm font-semibold focus:ring-2 focus:ring-amber-500 focus:bg-white transition"
              />
            </div>

          </div>

          {/* Section 2: Parties (Client & Opponent) */}
          <div className="space-y-4">
            <h3 className="text-xs font-black uppercase text-amber-700 tracking-wider flex items-center gap-2 border-b border-amber-100 pb-1">
              <Users className="w-4 h-4" />
              <span>أطراف الخصومة (الموكل والخصم)</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  اسم الموكل <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  placeholder="مثال: أحمد محمد علي"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-amber-500 focus:bg-white transition"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  صفة الموكل
                </label>
                <select
                  value={clientRole}
                  onChange={(e) => setClientRole(e.target.value as ClientRole)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-amber-500 focus:bg-white transition cursor-pointer"
                >
                  {ROLES.map((r) => (
                    <option key={r} value={r}>
                      {r}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  رقم هاتف الموكل (لإرسال تذكير واتساب)
                </label>
                <input
                  type="tel"
                  value={clientPhone}
                  onChange={(e) => setClientPhone(e.target.value)}
                  placeholder="010XXXXXXXX"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-sm font-mono focus:ring-2 focus:ring-amber-500 focus:bg-white transition"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  اسم الخصم / الشركة المشكو في حقها
                </label>
                <input
                  type="text"
                  value={opponentName}
                  onChange={(e) => setOpponentName(e.target.value)}
                  placeholder="مثال: شركة المقاولات الحديثة"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-amber-500 focus:bg-white transition"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-amber-900 mb-1 flex items-center justify-between">
                  <span className="flex items-center gap-1">
                    <UserCheck className="w-3.5 h-3.5 text-amber-600" />
                    <span>اسم المحامي الحاضر عن الموكل</span>
                  </span>
                  <span className="text-[10px] text-amber-700 bg-amber-100/80 px-1.5 py-0.2 rounded font-semibold">
                    بالجلسة
                  </span>
                </label>
                <input
                  type="text"
                  value={assignedLawyer}
                  onChange={(e) => setAssignedLawyer(e.target.value)}
                  placeholder="الأستاذ / ... (محامي الحضور والدفاع)"
                  className="w-full bg-amber-50/40 border border-amber-300 rounded-xl px-3 py-2 text-sm font-semibold text-slate-900 focus:ring-2 focus:ring-amber-500 focus:bg-white transition"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  محامي الخصم (اختياري)
                </label>
                <input
                  type="text"
                  value={opponentLawyer}
                  onChange={(e) => setOpponentLawyer(e.target.value)}
                  placeholder="الأستاذ / ..."
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-amber-500 focus:bg-white transition"
                />
              </div>
            </div>

          </div>

          {/* Section 3: Session Date, Time, Stage & 24h Alert */}
          <div className="space-y-4 bg-amber-50/40 p-4 rounded-2xl border border-amber-200">
            <h3 className="text-xs font-black uppercase text-amber-900 tracking-wider flex items-center gap-2 border-b border-amber-200/80 pb-1">
              <Clock className="w-4 h-4 text-amber-700" />
              <span>موعد الجلسة والتنبيه الذكي</span>
            </h3>

            {/* Quick Date Presets */}
            <div className="flex flex-wrap items-center gap-1.5 text-xs">
              <span className="text-slate-600 font-bold ml-1">تحديد سريع:</span>
              <button
                type="button"
                onClick={() => setSessionDate(today)}
                className={`px-2.5 py-1 rounded-lg font-bold transition cursor-pointer border ${
                  sessionDate === today ? 'bg-amber-500 text-slate-950 border-amber-600' : 'bg-white text-slate-700 border-slate-300'
                }`}
              >
                اليوم
              </button>
              <button
                type="button"
                onClick={() => setSessionDate(addDaysToDate(today, 1))}
                className={`px-2.5 py-1 rounded-lg font-bold transition cursor-pointer border ${
                  sessionDate === addDaysToDate(today, 1) ? 'bg-amber-500 text-slate-950 border-amber-600' : 'bg-white text-slate-700 border-slate-300'
                }`}
              >
                غداً
              </button>
              <button
                type="button"
                onClick={() => setSessionDate(addDaysToDate(today, 7))}
                className="px-2.5 py-1 rounded-lg bg-white text-slate-700 border border-slate-300 hover:bg-slate-50 transition cursor-pointer"
              >
                بعد أسبوع
              </button>
              <button
                type="button"
                onClick={() => setSessionDate(addDaysToDate(today, 14))}
                className="px-2.5 py-1 rounded-lg bg-white text-slate-700 border border-slate-300 hover:bg-slate-50 transition cursor-pointer"
              >
                بعد أسبوعين
              </button>
              <button
                type="button"
                onClick={() => setSessionDate(addDaysToDate(today, 30))}
                className="px-2.5 py-1 rounded-lg bg-white text-slate-700 border border-slate-300 hover:bg-slate-50 transition cursor-pointer"
              >
                بعد شهر
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  تاريخ الجلسة <span className="text-rose-500">*</span>
                </label>
                <input
                  type="date"
                  required
                  value={sessionDate}
                  onChange={(e) => setSessionDate(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-amber-500 transition"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  توقيت انعقاد الجلسة
                </label>
                <input
                  type="time"
                  value={sessionTime}
                  onChange={(e) => setSessionTime(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-amber-500 transition"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  نوع / مرحلة الجلسة
                </label>
                <select
                  value={sessionStage}
                  onChange={(e) => setSessionStage(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-amber-500 transition cursor-pointer"
                >
                  {STAGES.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Live Dual Date Display (Gregorian + Umm al-Qura) */}
            {sessionDate && (
              <div className="bg-white p-2.5 rounded-xl border border-amber-300 flex items-center justify-between gap-2 flex-wrap text-xs shadow-2xs">
                <div className="flex items-center gap-1.5 text-slate-900 font-bold">
                  <Calendar className="w-4 h-4 text-amber-600" />
                  <span>الميلادي: {formatArabicDate(sessionDate, { includeWeekday: true })}</span>
                </div>
                <div className="flex items-center gap-1.5 text-emerald-800 font-bold bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
                  <Moon className="w-3.5 h-3.5 text-emerald-600" />
                  <span>تقويم أم القرى: {formatHijriDate(sessionDate, { includeWeekday: false })}</span>
                </div>
              </div>
            )}

            {/* Smart 24h Alert Checkbox */}
            <div className="flex items-center gap-3 bg-white p-3 rounded-xl border border-amber-300 shadow-xs">
              <input
                type="checkbox"
                id="remind24h"
                checked={remind24h}
                onChange={(e) => setRemind24h(e.target.checked)}
                className="w-4 h-4 text-amber-600 rounded border-slate-300 focus:ring-amber-500 cursor-pointer"
              />
              <label htmlFor="remind24h" className="text-xs text-slate-800 font-bold flex items-center gap-1.5 cursor-pointer">
                <Bell className="w-4 h-4 text-amber-600" />
                <span>تفعيل التنبيه الذكي قبل موعد الجلسة بـ 24 ساعة (إشعار مرئي وصوتي وتذكير فوري)</span>
              </label>
            </div>

          </div>

          {/* Section 4: Decisions & Demands */}
          <div className="space-y-4">
            <h3 className="text-xs font-black uppercase text-amber-700 tracking-wider flex items-center gap-2 border-b border-amber-100 pb-1">
              <FileText className="w-4 h-4" />
              <span>القرارات والطلبات وملاحظات الدفاع</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  المطلوب في الجلسة القادمة
                </label>
                <textarea
                  rows={2}
                  value={demands}
                  onChange={(e) => setDemands(e.target.value)}
                  placeholder="مثال: تقديم مذكرة بالرد على الدفوع وسماع الشهود..."
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-sm focus:ring-2 focus:ring-amber-500 focus:bg-white transition"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  قرار الجلسة السابقة (إن وجد)
                </label>
                <textarea
                  rows={2}
                  value={previousDecision}
                  onChange={(e) => setPreviousDecision(e.target.value)}
                  placeholder="مثال: التأجيل لجلسة اليوم لإعلان الخصم بالطلبات العارضة"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-sm focus:ring-2 focus:ring-amber-500 focus:bg-white transition"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                ملاحظات وتوجيهات خاصة
              </label>
              <textarea
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="أي ملاحظات إضافية حول القاعة، الرسوم، الموكل، أو السكرتير..."
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-sm focus:ring-2 focus:ring-amber-500 focus:bg-white transition"
              />
            </div>
          </div>

          {/* Section 5: Preparation Checklist */}
          <div className="space-y-3">
            <h3 className="text-xs font-black uppercase text-amber-700 tracking-wider flex items-center gap-2 border-b border-amber-100 pb-1">
              <CheckSquare className="w-4 h-4" />
              <span>قائمة تجهيزات ومهام الجلسة</span>
            </h3>

            {/* Quick Presets */}
            <div className="flex flex-wrap gap-1.5 text-xs mb-2">
              <span className="text-slate-500 font-semibold ml-1">إضافة سريعة:</span>
              {QUICK_CHECKLIST_PRESETS.map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => handleAddChecklistItem(preset)}
                  className="px-2 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs transition cursor-pointer border border-slate-200"
                >
                  + {preset}
                </button>
              ))}
            </div>

            {/* Checklist items */}
            <div className="space-y-2">
              {checklist.map((item) => (
                <div 
                  key={item.id}
                  className="flex items-center justify-between bg-slate-50 p-2.5 rounded-xl border border-slate-200 text-xs"
                >
                  <button
                    type="button"
                    onClick={() => handleToggleChecklist(item.id)}
                    className="flex items-center gap-2 text-right flex-1 cursor-pointer font-medium text-slate-800"
                  >
                    <div className={`w-4 h-4 rounded flex items-center justify-center border ${
                      item.completed ? 'bg-emerald-600 border-emerald-600 text-white' : 'border-slate-300 bg-white'
                    }`}>
                      {item.completed && <Check className="w-3 h-3" />}
                    </div>
                    <span className={item.completed ? 'line-through text-slate-400' : ''}>
                      {item.text}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleRemoveChecklistItem(item.id)}
                    className="text-slate-400 hover:text-rose-600 p-1 transition cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>

            {/* Add Custom Item */}
            <div className="flex gap-2">
              <input
                type="text"
                value={newChecklistText}
                onChange={(e) => setNewChecklistText(e.target.value)}
                placeholder="أضف مهمة تجهيز خاصة..."
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddChecklistItem(newChecklistText);
                  }
                }}
                className="flex-1 bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs focus:ring-2 focus:ring-amber-500 focus:bg-white"
              />
              <button
                type="button"
                onClick={() => handleAddChecklistItem(newChecklistText)}
                className="px-3 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold hover:bg-slate-800 transition cursor-pointer"
              >
                إضافة
              </button>
            </div>

          </div>

        </form>

        {/* Modal Footer */}
        <div className="bg-slate-100 px-6 py-4 border-t border-slate-200 flex items-center justify-end gap-3 shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-white hover:bg-slate-200 text-slate-700 border border-slate-300 rounded-xl text-xs font-bold transition cursor-pointer"
          >
            إلغاء
          </button>
          
          <button
            type="button"
            onClick={handleSubmit}
            className="px-6 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-extrabold rounded-xl text-xs sm:text-sm shadow-md transition cursor-pointer"
          >
            {initialData ? 'حفظ التعديلات' : 'حفظ القضية والجدولة'}
          </button>
        </div>

      </div>
    </div>
  );
};
