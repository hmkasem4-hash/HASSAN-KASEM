import React, { useState, useMemo } from 'react';
import { 
  X, 
  Printer, 
  Building2, 
  Calendar, 
  Download, 
  Scale, 
  FileText,
  FileSpreadsheet,
  UserCheck,
  User,
  Moon
} from 'lucide-react';
import { CourtCase } from '../types';
import { formatArabicDate, formatArabicTime, formatHijriDate, getTodayString } from '../utils/dateUtils';

interface CourtRollPrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  cases: CourtCase[];
  allCourts: string[];
}

export const CourtRollPrintModal: React.FC<CourtRollPrintModalProps> = ({
  isOpen,
  onClose,
  cases,
  allCourts,
}) => {
  const today = getTodayString();
  const [selectedDate, setSelectedDate] = useState(today);
  const [selectedCourt, setSelectedCourt] = useState('all');
  const [selectedLawyer, setSelectedLawyer] = useState('all');
  const [lawyerName, setLawyerName] = useState('مكتب الأستاذ / المحامي');

  // Extract unique assigned lawyers
  const allLawyers = useMemo(() => {
    const set = new Set<string>();
    cases.forEach((c) => {
      if (c.assignedLawyer && c.assignedLawyer.trim()) {
        set.add(c.assignedLawyer.trim());
      }
    });
    return Array.from(set);
  }, [cases]);

  if (!isOpen) return null;

  // Filter cases for the roll
  const filteredCases = cases.filter((c) => {
    const matchDate = selectedDate ? c.sessionDate === selectedDate : true;
    const matchCourt = selectedCourt === 'all' ? true : c.court === selectedCourt;
    const matchLawyer = selectedLawyer === 'all' ? true : (c.assignedLawyer === selectedLawyer);
    return matchDate && matchCourt && matchLawyer;
  });

  const handlePrint = () => {
    window.print();
  };

  const handleExportCSV = () => {
    // Generate CSV with lawyer name and dedicated time column
    const headers = [
      'رقم القضية',
      'السنة',
      'ساعة وموعد الجلسة',
      'المحكمة',
      'الدائرة',
      'الموكل',
      'الصفة',
      'المحامي الحاضر عن الموكل',
      'الخصم',
      'محامي الخصم',
      'نوع الجلسة',
      'المطلوب'
    ];
    const rows = filteredCases.map((c) => [
      c.caseNumber,
      c.caseYear,
      `"${formatArabicTime(c.sessionTime)} (${c.sessionTime})"`,
      `"${c.court}"`,
      `"${c.circuit}"`,
      `"${c.clientName}"`,
      `"${c.clientRole}"`,
      `"${c.assignedLawyer || lawyerName}"`,
      `"${c.opponentName}"`,
      `"${c.opponentLawyer || ''}"`,
      `"${c.sessionStage}"`,
      `"${c.demands || ''}"`,
    ]);

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `رول_جلسات_${selectedDate}_${selectedLawyer !== 'all' ? selectedLawyer : 'شامل'}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 animate-in fade-in">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-5xl w-full max-h-[95vh] flex flex-col overflow-hidden">
        
        {/* Modal Controls Bar (No Print) */}
        <div className="bg-slate-900 text-white px-6 py-4 flex flex-wrap items-center justify-between gap-3 shrink-0 border-b border-slate-800 no-print">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-500 text-slate-950 rounded-xl font-bold">
              <Printer className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-extrabold text-white">
                طباعة رول الجلسات اليومي للمحكمة
              </h2>
              <p className="text-xs text-slate-400">
                جدول منسق متضمن أسماء المحامين الحاضرين جاهز للطباعة والاصطحاب لقاعات الجلسات
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExportCSV}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
              <span>تصدير Excel (CSV)</span>
            </button>

            <button
              onClick={handlePrint}
              className="px-4 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded-xl text-xs font-black transition flex items-center gap-1.5 cursor-pointer shadow-md"
            >
              <Printer className="w-4 h-4" />
              <span>طباعة الرول الآن</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Filter Controls (No Print) */}
        <div className="bg-slate-100 p-4 border-b border-slate-200 flex flex-wrap items-center gap-3 text-xs shrink-0 no-print">
          
          <div className="flex items-center gap-1.5">
            <label className="font-bold text-slate-700">تاريخ الرول:</label>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="bg-white border border-slate-300 rounded-xl px-3 py-1.5 text-xs font-bold"
            />
          </div>

          <div className="flex items-center gap-1.5">
            <label className="font-bold text-slate-700">المحكمة:</label>
            <select
              value={selectedCourt}
              onChange={(e) => setSelectedCourt(e.target.value)}
              className="bg-white border border-slate-300 rounded-xl px-3 py-1.5 text-xs font-medium cursor-pointer"
            >
              <option value="all">كافة المحاكم ({cases.length})</option>
              {allCourts.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          {/* Lawyer Filter */}
          <div className="flex items-center gap-1.5">
            <label className="font-bold text-slate-700 flex items-center gap-1">
              <UserCheck className="w-3.5 h-3.5 text-amber-600" />
              <span>المحامي الحاضر:</span>
            </label>
            <select
              value={selectedLawyer}
              onChange={(e) => setSelectedLawyer(e.target.value)}
              className="bg-white border border-slate-300 rounded-xl px-3 py-1.5 text-xs font-medium cursor-pointer"
            >
              <option value="all">كافة المحامين ({allLawyers.length || 'الكل'})</option>
              {allLawyers.map((l) => (
                <option key={l} value={l}>
                  {l}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1.5 flex-1 min-w-[200px] max-w-xs">
            <label className="font-bold text-slate-700">ترويسة المكتب:</label>
            <input
              type="text"
              value={lawyerName}
              onChange={(e) => setLawyerName(e.target.value)}
              placeholder="اسم المحامي أو المكتب..."
              className="w-full bg-white border border-slate-300 rounded-xl px-3 py-1.5 text-xs font-semibold"
            />
          </div>

          <span className="text-slate-500 font-bold ml-auto">
            إجمالي القضايا بالرول: <strong className="text-slate-900">{filteredCases.length}</strong>
          </span>
        </div>

        {/* Printable Official Judicial Sheet */}
        <div className="flex-1 overflow-y-auto p-6 sm:p-8 bg-white text-slate-900 font-sans">
          
          {/* Printable Official Header */}
          <div className="border-b-2 border-slate-900 pb-4 mb-6 text-center print-break-inside-avoid">
            <div className="flex items-center justify-between mb-2">
              <div className="text-right">
                <span className="font-bold text-sm block text-slate-900">{lawyerName}</span>
                <span className="text-[11px] text-slate-600 block">للمحاماة والاستشارات القانونية</span>
                {selectedLawyer !== 'all' && (
                  <span className="text-xs text-amber-800 font-bold block mt-0.5 bg-amber-50 px-2 py-0.5 rounded border border-amber-200 inline-block">
                    رول المحامي الحاضر: {selectedLawyer}
                  </span>
                )}
              </div>
              
              <div className="flex items-center gap-2">
                <Scale className="w-8 h-8 text-slate-900" />
              </div>

              <div className="text-left text-xs text-slate-800 space-y-0.5">
                <div>تاريخ الرول (ميلادي): <strong className="font-mono">{selectedDate}</strong></div>
                <div className="text-[11px] text-slate-600 font-semibold">الموافق (أم القرى): {formatHijriDate(selectedDate)}</div>
              </div>
            </div>

            <h1 className="text-xl sm:text-2xl font-black text-slate-900 uppercase tracking-tight">
              رول جلسات يوم {formatArabicDate(selectedDate)}
            </h1>
            <div className="text-xs font-bold text-emerald-900 mt-0.5">
              الموافق: {formatHijriDate(selectedDate, { includeWeekday: true })} (تقويم أم القرى)
            </div>
            <div className="flex items-center justify-center gap-3 text-xs font-bold text-slate-600 mt-1 flex-wrap">
              <span>{selectedCourt === 'all' ? 'كافة المحاكم' : `محكمة: ${selectedCourt}`}</span>
              <span>•</span>
              <span>{selectedLawyer === 'all' ? 'جميع محامي المكتب' : `المحامي الحاضر: ${selectedLawyer}`}</span>
            </div>
          </div>

          {/* Printable Table */}
          {filteredCases.length === 0 ? (
            <div className="p-12 text-center text-slate-500 border border-dashed border-slate-300 rounded-2xl">
              لا توجد جلسات مسجلة في هذا التاريخ المحدد ({selectedDate})
              {selectedLawyer !== 'all' && ` للمحامي: ${selectedLawyer}`}
            </div>
          ) : (
            <table className="w-full border-collapse border border-slate-900 text-xs text-right">
              <thead>
                <tr className="bg-slate-100 text-slate-950 font-black border-b-2 border-slate-900">
                  <th className="border border-slate-800 p-2 w-8 text-center">م</th>
                  <th className="border border-slate-800 p-2 w-28 text-center">رقم الدعوى والسنة</th>
                  <th className="border border-slate-800 p-2 w-24 text-center bg-amber-50/80 text-amber-950 font-black">
                    ساعة الجلسة
                  </th>
                  <th className="border border-slate-800 p-2 w-32">المحكمة والدائرة</th>
                  <th className="border border-slate-800 p-2 w-32">اسم الموكل (الصفة)</th>
                  <th className="border border-slate-800 p-2 w-32 bg-amber-50/70 text-amber-950">المحامي الحاضر عن الموكل</th>
                  <th className="border border-slate-800 p-2 w-32">الخصم ومحاميه</th>
                  <th className="border border-slate-800 p-2">نوع الجلسة والمطلوب</th>
                  <th className="border border-slate-800 p-2 w-44 text-center">القرار الصادر بالجلسة (يدوياً)</th>
                </tr>
              </thead>
              <tbody>
                {filteredCases.map((c, index) => (
                  <tr key={c.id} className="border-b border-slate-400 print-break-inside-avoid">
                    <td className="border border-slate-400 p-2 text-center font-bold font-mono">
                      {index + 1}
                    </td>

                    <td className="border border-slate-400 p-2 text-center font-mono font-bold">
                      <div className="text-slate-900 text-sm">{c.caseNumber}</div>
                      <div className="text-[10px] text-slate-600">لسنة {c.caseYear}</div>
                    </td>

                    {/* Dedicated Session Time Column */}
                    <td className="border border-slate-400 p-2 text-center bg-amber-50/40">
                      <div className="font-bold text-slate-900 text-xs font-sans">
                        {formatArabicTime(c.sessionTime)}
                      </div>
                      <div className="text-[10px] text-amber-800 font-mono font-bold mt-0.5">
                        {c.sessionTime}
                      </div>
                    </td>

                    <td className="border border-slate-400 p-2">
                      <strong className="block text-slate-900">{c.court}</strong>
                      <span className="text-slate-600 text-[11px] block">{c.circuit}</span>
                      {c.judge && <span className="text-slate-500 text-[10px] block">رئيس: {c.judge}</span>}
                    </td>

                    <td className="border border-slate-400 p-2">
                      <strong className="text-slate-900 block">{c.clientName}</strong>
                      <span className="text-slate-700 text-[10px]">({c.clientRole})</span>
                    </td>

                    {/* Assigned Lawyer Column */}
                    <td className="border border-slate-400 p-2 bg-amber-50/30">
                      <strong className="text-slate-900 font-bold block">
                        {c.assignedLawyer || lawyerName}
                      </strong>
                    </td>

                    <td className="border border-slate-400 p-2">
                      <span className="text-slate-900 block font-medium">{c.opponentName}</span>
                      {c.opponentLawyer ? (
                        <div className="text-[10px] text-slate-600 mt-0.5 bg-slate-100 p-1 rounded">
                          محامي الخصم: <strong className="text-slate-800">{c.opponentLawyer}</strong>
                        </div>
                      ) : (
                        <span className="text-[10px] text-slate-400">بدون محامٍ مسجل</span>
                      )}
                    </td>

                    <td className="border border-slate-400 p-2">
                      <span className="font-bold text-slate-900 block">{c.sessionStage}</span>
                      {c.demands && (
                        <p className="text-slate-700 text-[11px] mt-0.5 leading-snug">
                          {c.demands}
                        </p>
                      )}
                    </td>

                    <td className="border border-slate-400 p-2 bg-slate-50/50 min-h-[45px]">
                      {/* Empty space for lawyer handwritten decision in court */}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {/* Printable Footer */}
          <div className="mt-8 pt-4 border-t border-slate-300 text-slate-500 text-[11px] flex items-center justify-between print-break-inside-avoid">
            <span>تم استخراج الرول عبر نظام إدارة الجلسات ومواعيد القضايا الذكي</span>
            <span>المكتب: {lawyerName}</span>
            <span>الصفحة 1 من 1</span>
          </div>

        </div>

      </div>
    </div>
  );
};

