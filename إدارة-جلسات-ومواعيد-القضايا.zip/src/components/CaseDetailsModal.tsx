import React, { useState, useEffect } from 'react';
import { 
  X, 
  Building2, 
  Calendar, 
  Clock, 
  User, 
  Users, 
  UserCheck,
  FileText, 
  CheckCircle2, 
  Circle, 
  Send, 
  Phone, 
  Printer, 
  ArrowRightLeft, 
  Edit3, 
  History, 
  Plus, 
  Check, 
  Copy,
  AlertTriangle,
  Scale,
  FileCheck,
  CalendarPlus,
  Sparkles
} from 'lucide-react';
import { CourtCase } from '../types';
import { 
  formatArabicDate, 
  formatArabicTime, 
  formatHijriDate,
  getCountdownBadge, 
  isWithin24Hours,
  getTodayString,
  addDaysToDate
} from '../utils/dateUtils';

interface CaseDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  caseItem: CourtCase | null;
  onEdit: (c: CourtCase) => void;
  onPostpone: (c: CourtCase) => void;
  onUpdateNextSession?: (
    caseId: string,
    data: {
      nextDate: string;
      nextTime: string;
      nextDemands?: string;
      decisionNote?: string;
      assignedLawyer?: string;
    }
  ) => void;
  onToggleChecklist: (caseId: string, itemId: string) => void;
  onAddChecklistItem: (caseId: string, text: string) => void;
}

export const CaseDetailsModal: React.FC<CaseDetailsModalProps> = ({
  isOpen,
  onClose,
  caseItem,
  onEdit,
  onPostpone,
  onUpdateNextSession,
  onToggleChecklist,
  onAddChecklistItem,
}) => {
  const [newItemText, setNewItemText] = useState('');
  const [copied, setCopied] = useState(false);
  const [successSaved, setSuccessSaved] = useState(false);

  // Next session form fields
  const [nextDate, setNextDate] = useState('');
  const [nextTime, setNextTime] = useState('09:30');
  const [nextLawyer, setNextLawyer] = useState('');
  const [nextDemands, setNextDemands] = useState('');
  const [decisionNote, setDecisionNote] = useState('');
  const [showNextForm, setShowNextForm] = useState(false);

  useEffect(() => {
    if (caseItem) {
      setNextDate(addDaysToDate(caseItem.sessionDate, 14));
      setNextTime(caseItem.sessionTime || '09:30');
      setNextLawyer(caseItem.assignedLawyer || '');
      setNextDemands(caseItem.demands || '');
      setDecisionNote('');
      setSuccessSaved(false);
    }
  }, [caseItem?.id, caseItem?.sessionDate, caseItem?.sessionTime, caseItem?.assignedLawyer]);

  if (!isOpen || !caseItem) return null;

  const today = getTodayString();
  const countdown = getCountdownBadge(caseItem.sessionDate, caseItem.sessionTime);
  const urgent24h = isWithin24Hours(caseItem);

  const handleCopySummary = () => {
    const lawyerInfo = caseItem.assignedLawyer ? `\nالمحامي الحاضر عن الموكل: ${caseItem.assignedLawyer}` : '';
    const text = `ملخص القضية:\nرقم: ${caseItem.caseNumber} لسنة ${caseItem.caseYear}\nالمحكمة: ${caseItem.court} (${caseItem.circuit})\nالموضوع: ${caseItem.title}\nالموكل: ${caseItem.clientName} (${caseItem.clientRole})${lawyerInfo}\nالخصم: ${caseItem.opponentName}\nالجلسة: ${formatArabicDate(caseItem.sessionDate)} الموافق هجرياً (${formatHijriDate(caseItem.sessionDate)} تقويم أم القرى) الساعة ${formatArabicTime(caseItem.sessionTime)}\nالمطلوب: ${caseItem.demands || 'مرافعة'}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSendWhatsApp = () => {
    if (!caseItem.clientPhone) return;
    const cleanPhone = caseItem.clientPhone.replace(/[^0-9]/g, '');
    const lawyerLine = caseItem.assignedLawyer ? `\nالمحامي الحاضر عن الموكل بالجلسة: ${caseItem.assignedLawyer}` : '';
    const message = encodeURIComponent(
      `السلام عليكم أستاذ/ة ${caseItem.clientName}،\nنحيطكم علماً بأن موعد الجلسة القادمة في القضية رقم (${caseItem.caseNumber} لسنة ${caseItem.caseYear})\nالمحكمة: ${caseItem.court} - ${caseItem.circuit}${lawyerLine}\nالتاريخ: ${formatArabicDate(caseItem.sessionDate)} الموافق هجرياً (${formatHijriDate(caseItem.sessionDate)} تقويم أم القرى) الساعة ${formatArabicTime(caseItem.sessionTime)}\nالمطلوب: ${caseItem.demands || 'الحضور لمقر المحكمة'}\nشاكرين تعاونكم.`
    );
    window.open(`https://wa.me/${cleanPhone}?text=${message}`, '_blank');
  };

  const handleAddItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemText.trim()) return;
    onAddChecklistItem(caseItem.id, newItemText.trim());
    setNewItemText('');
  };

  const handlePrintCase = () => {
    window.print();
  };

  const handleSaveNextSchedule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nextDate) {
      alert('يرجى تحديد تاريخ الجلسة القادمة');
      return;
    }

    if (onUpdateNextSession) {
      onUpdateNextSession(caseItem.id, {
        nextDate,
        nextTime: nextTime || '09:30',
        nextDemands,
        decisionNote: decisionNote.trim() || `تأجيل وتحديد موعد الجلسة القادمة ليوم ${formatArabicDate(nextDate)}`,
        assignedLawyer: nextLawyer.trim(),
      });
    }

    setSuccessSaved(true);
    setTimeout(() => {
      setSuccessSaved(false);
    }, 4000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 no-print animate-in fade-in">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-3xl w-full max-h-[92vh] flex flex-col overflow-hidden">
        
        {/* Header */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between shrink-0 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-500 text-slate-950 rounded-xl font-bold">
              <Scale className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded-lg text-xs font-mono font-bold">
                  دعوى {caseItem.caseNumber} / {caseItem.caseYear}
                </span>
                <span className="px-2 py-0.5 bg-slate-800 text-slate-300 rounded-lg text-xs">
                  {caseItem.court}
                </span>
              </div>
              <h2 className="text-base sm:text-lg font-extrabold text-white mt-1">
                {caseItem.title}
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrintCase}
              title="طباعة تقرير القضية"
              className="p-2 hover:bg-slate-800 text-slate-300 rounded-xl transition cursor-pointer"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          
          {/* Urgent 24h Banner if applicable */}
          {urgent24h && (
            <div className="bg-amber-500/10 border-2 border-amber-500/40 rounded-2xl p-3 flex items-center justify-between gap-3 text-amber-900">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-amber-600 animate-pulse shrink-0" />
                <span className="text-xs sm:text-sm font-bold">
                  تنبيه عاجل: الجلسة منعقدة خلال أقل من 24 ساعة!
                </span>
              </div>
              <span className={`px-2.5 py-1 text-xs font-bold rounded-lg border ${countdown.colorClass}`}>
                {countdown.text}
              </span>
            </div>
          )}

          {/* Session Date & Circuit Banner */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-slate-900 text-white p-4 rounded-2xl flex items-center justify-between shadow-inner">
              <div className="flex items-center gap-3">
                <Calendar className="w-6 h-6 text-amber-400 shrink-0" />
                <div>
                  <span className="text-[11px] text-slate-400 block font-bold">تاريخ انعقاد الجلسة الحالي</span>
                  <span className="font-extrabold text-sm sm:text-base text-white block">
                    {formatArabicDate(caseItem.sessionDate)}
                  </span>
                  <span className="text-xs text-amber-300 font-medium">
                    {formatHijriDate(caseItem.sessionDate)} (تقويم أم القرى)
                  </span>
                </div>
              </div>
              <div className="font-mono font-bold text-amber-400 bg-slate-800 px-2.5 py-1 rounded-xl text-xs sm:text-sm border border-slate-700 text-center">
                <span className="block">{formatArabicTime(caseItem.sessionTime)}</span>
                <span className="text-[10px] text-slate-400 font-mono">({caseItem.sessionTime})</span>
              </div>
            </div>

            <div className="bg-slate-50 border border-slate-200 p-4 rounded-2xl flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Building2 className="w-6 h-6 text-slate-700" />
                <div>
                  <span className="text-[11px] text-slate-500 block font-bold">المحكمة والدائرة</span>
                  <span className="font-bold text-sm text-slate-900">{caseItem.court}</span>
                  <span className="text-xs text-slate-600 block">{caseItem.circuit}</span>
                </div>
              </div>
              {caseItem.judge && (
                <span className="text-[11px] text-slate-600 bg-white px-2 py-1 rounded-lg border border-slate-200">
                  {caseItem.judge}
                </span>
              )}
            </div>
          </div>

          {/* DEDICATED NEXT SESSION SCHEDULER SECTION */}
          <div className="bg-gradient-to-br from-amber-500/10 via-amber-500/5 to-slate-50 border-2 border-amber-400/80 rounded-2xl p-4 sm:p-5 shadow-sm space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-amber-200/80 pb-2.5">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-amber-500 text-slate-950 rounded-xl font-bold">
                  <CalendarPlus className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-900">
                    تحديد وإضافة الموعد القادم للجلسة (تلقائياً)
                  </h3>
                  <p className="text-[11px] text-slate-600">
                    عند إدخال التاريخ القادم يُضاف ويُجدول فوراً في قسم "الجلسات القادمة" والتقويم ورول المحكمة
                  </p>
                </div>
              </div>

              {successSaved && (
                <span className="px-3 py-1 bg-emerald-600 text-white text-xs font-bold rounded-lg flex items-center gap-1 shadow animate-in fade-in">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>تمت الإضافة بنجاح للجلسات القادمة!</span>
                </span>
              )}
            </div>

            {/* Quick Date Presets */}
            <div className="flex flex-wrap items-center gap-1.5 text-xs pt-1">
              <span className="text-slate-700 font-bold ml-1 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-amber-600" />
                <span>خيارات سريعة للموعد القادم:</span>
              </span>
              <button
                type="button"
                onClick={() => setNextDate(addDaysToDate(caseItem.sessionDate || today, 7))}
                className="px-2.5 py-1 rounded-lg bg-white hover:bg-amber-100/60 text-slate-800 border border-slate-300 font-bold transition cursor-pointer"
              >
                + أسبوع
              </button>
              <button
                type="button"
                onClick={() => setNextDate(addDaysToDate(caseItem.sessionDate || today, 14))}
                className="px-2.5 py-1 rounded-lg bg-white hover:bg-amber-100/60 text-slate-800 border border-slate-300 font-bold transition cursor-pointer"
              >
                + أسبوعين
              </button>
              <button
                type="button"
                onClick={() => setNextDate(addDaysToDate(caseItem.sessionDate || today, 21))}
                className="px-2.5 py-1 rounded-lg bg-white hover:bg-amber-100/60 text-slate-800 border border-slate-300 font-bold transition cursor-pointer"
              >
                + 3 أسابيع
              </button>
              <button
                type="button"
                onClick={() => setNextDate(addDaysToDate(caseItem.sessionDate || today, 30))}
                className="px-2.5 py-1 rounded-lg bg-white hover:bg-amber-100/60 text-slate-800 border border-slate-300 font-bold transition cursor-pointer"
              >
                + شهر (30 يوماً)
              </button>
            </div>

            {/* Next Schedule Form */}
            <form onSubmit={handleSaveNextSchedule} className="space-y-3 pt-1">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    تاريخ الجلسة القادمة <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="date"
                    required
                    value={nextDate}
                    onChange={(e) => setNextDate(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs sm:text-sm font-semibold focus:ring-2 focus:ring-amber-500 focus:bg-white transition"
                  />
                  {nextDate && (
                    <div className="text-[10px] text-emerald-800 font-bold mt-1 bg-emerald-50/80 px-2 py-0.5 rounded border border-emerald-200">
                      الموافق: {formatHijriDate(nextDate)} (أم القرى)
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    ساعة وموعد الجلسة
                  </label>
                  <input
                    type="time"
                    value={nextTime}
                    onChange={(e) => setNextTime(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs sm:text-sm font-semibold focus:ring-2 focus:ring-amber-500 focus:bg-white transition"
                  />
                  {nextTime && (
                    <div className="text-[10px] text-slate-600 font-bold mt-1">
                      التوقيت: {formatArabicTime(nextTime)}
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    المحامي الحاضر عن الموكل بالجلسة القادمة
                  </label>
                  <input
                    type="text"
                    value={nextLawyer}
                    onChange={(e) => setNextLawyer(e.target.value)}
                    placeholder="اسم المحامي المكلف بالحضور..."
                    className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs sm:text-sm font-semibold focus:ring-2 focus:ring-amber-500 focus:bg-white transition"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    المطلوب في الجلسة القادمة
                  </label>
                  <input
                    type="text"
                    value={nextDemands}
                    onChange={(e) => setNextDemands(e.target.value)}
                    placeholder="مرافعة، تقديم مذكرات، سماع شهود، إلخ..."
                    className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold focus:ring-2 focus:ring-amber-500 focus:bg-white transition"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    سبب التأجيل / قرار الجلسة السابقة للتوثيق
                  </label>
                  <input
                    type="text"
                    value={decisionNote}
                    onChange={(e) => setDecisionNote(e.target.value)}
                    placeholder="مثال: تأجيل لتقديم مستندات رسمية أو لإعادة الإعلان..."
                    className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold focus:ring-2 focus:ring-amber-500 focus:bg-white transition"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end pt-1">
                <button
                  type="submit"
                  className="w-full sm:w-auto px-5 py-2.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black rounded-xl text-xs sm:text-sm flex items-center justify-center gap-2 shadow transition cursor-pointer"
                >
                  <CalendarPlus className="w-4 h-4" />
                  <span>تثبيت وإضافة الموعد القادم تلقائياً إلى الجلسات القادمة</span>
                </button>
              </div>
            </form>
          </div>

          {/* Parties Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            {/* Client Card */}
            <div className="bg-emerald-50/50 border border-emerald-200/80 rounded-2xl p-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-emerald-900 uppercase">الموكل</span>
                <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[10px] font-bold rounded-md">
                  {caseItem.clientRole}
                </span>
              </div>
              <div className="text-base font-extrabold text-slate-900">{caseItem.clientName}</div>
              
              {caseItem.clientPhone && (
                <div className="flex items-center justify-between pt-2 border-t border-emerald-200/60 text-xs">
                  <span className="font-mono text-slate-700">{caseItem.clientPhone}</span>
                  <div className="flex items-center gap-2">
                    <a
                      href={`tel:${caseItem.clientPhone}`}
                      className="px-2 py-1 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-lg font-bold flex items-center gap-1"
                    >
                      <Phone className="w-3 h-3" />
                      اتصال
                    </a>
                    <button
                      onClick={handleSendWhatsApp}
                      className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <Send className="w-3 h-3" />
                      واتساب
                    </button>
                  </div>
                </div>
              )}

              {caseItem.assignedLawyer && (
                <div className="text-xs text-emerald-950 pt-2 border-t border-emerald-200/60 bg-emerald-100/60 p-2.5 rounded-xl flex items-center justify-between gap-2">
                  <div>
                    <span className="text-[11px] text-emerald-800 font-semibold flex items-center gap-1">
                      <UserCheck className="w-3.5 h-3.5 text-emerald-700" />
                      <span>المحامي الحاضر عن الموكل بالجلسة:</span>
                    </span>
                    <strong className="text-slate-900 font-extrabold text-xs block mt-0.5">{caseItem.assignedLawyer}</strong>
                  </div>
                </div>
              )}
            </div>

            {/* Opponent Card */}
            <div className="bg-rose-50/50 border border-rose-200/80 rounded-2xl p-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-rose-900 uppercase">الخصم</span>
                <span className="px-2 py-0.5 bg-rose-100 text-rose-800 text-[10px] font-bold rounded-md">
                  الطرف الثاني
                </span>
              </div>
              <div className="text-base font-extrabold text-slate-900">{caseItem.opponentName}</div>
              {caseItem.opponentLawyer && (
                <div className="text-xs text-slate-600 pt-2 border-t border-rose-200/60">
                  <span>محامي الخصم: </span>
                  <strong className="text-slate-800">{caseItem.opponentLawyer}</strong>
                </div>
              )}
            </div>

          </div>

          {/* Session Demands & Previous Decisions */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-700">مرحلة ونوع الجلسة:</span>
              <span className="px-2.5 py-1 bg-amber-100 text-amber-900 font-extrabold rounded-lg text-xs">
                {caseItem.sessionStage}
              </span>
            </div>

            {caseItem.demands && (
              <div>
                <span className="text-xs font-bold text-amber-900 block mb-1">
                  📌 المطلوب في الجلسة:
                </span>
                <p className="text-xs sm:text-sm text-slate-800 bg-white p-3 rounded-xl border border-slate-200 leading-relaxed font-medium">
                  {caseItem.demands}
                </p>
              </div>
            )}

            {caseItem.previousDecision && (
              <div>
                <span className="text-xs font-bold text-slate-600 block mb-1">
                  ⚖️ قرار الجلسة السابقة:
                </span>
                <p className="text-xs text-slate-700 bg-white p-3 rounded-xl border border-slate-200 leading-relaxed">
                  {caseItem.previousDecision}
                </p>
              </div>
            )}

            {caseItem.notes && (
              <div>
                <span className="text-xs font-bold text-slate-600 block mb-1">
                  📝 ملاحظات المحامي الخاصة:
                </span>
                <p className="text-xs text-slate-700 bg-white p-3 rounded-xl border border-slate-200 leading-relaxed">
                  {caseItem.notes}
                </p>
              </div>
            )}
          </div>

          {/* Interactive Preparation Checklist */}
          <div className="bg-white border border-slate-200 rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                <FileCheck className="w-4 h-4 text-amber-600" />
                <span>قائمة تجهيزات ومستندات الجلسة</span>
              </h3>
              <span className="text-xs text-slate-500 font-bold">
                {caseItem.checklist.filter((i) => i.completed).length} من {caseItem.checklist.length} مكتملة
              </span>
            </div>

            <div className="space-y-2">
              {caseItem.checklist.map((item) => (
                <button
                  key={item.id}
                  onClick={() => onToggleChecklist(caseItem.id, item.id)}
                  className="w-full flex items-center gap-2.5 text-right p-2.5 rounded-xl hover:bg-slate-50 border border-slate-100 transition cursor-pointer text-xs sm:text-sm"
                >
                  {item.completed ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  ) : (
                    <Circle className="w-4 h-4 text-slate-400 shrink-0" />
                  )}
                  <span className={item.completed ? 'line-through text-slate-400 font-normal' : 'text-slate-800 font-semibold'}>
                    {item.text}
                  </span>
                </button>
              ))}
            </div>

            {/* Add item inline */}
            <form onSubmit={handleAddItem} className="flex gap-2 pt-2">
              <input
                type="text"
                value={newItemText}
                onChange={(e) => setNewItemText(e.target.value)}
                placeholder="أضف مهمة تجهيز أو مستند مطلوب..."
                className="flex-1 bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs focus:ring-2 focus:ring-amber-500 focus:bg-white"
              />
              <button
                type="submit"
                className="px-3 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold hover:bg-slate-800 transition cursor-pointer"
              >
                + إضافة
              </button>
            </form>
          </div>

          {/* Historic Decisions Log */}
          {caseItem.history && caseItem.history.length > 0 && (
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3">
              <h3 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                <History className="w-4 h-4 text-sky-600" />
                <span>السجل التاريخي للقرارات السابقة للدعوى ({caseItem.history.length})</span>
              </h3>

              <div className="space-y-2.5">
                {caseItem.history.map((h, idx) => (
                  <div key={h.id || idx} className="bg-white p-3 rounded-xl border border-slate-200 text-xs space-y-1">
                    <div className="flex items-center justify-between text-slate-500 font-mono">
                      <span>جلسة تاريخ: {formatArabicDate(h.date)}</span>
                      {h.lawyer && (
                        <span className="text-amber-800 bg-amber-50 px-2 py-0.5 rounded text-[10px] font-sans font-bold border border-amber-200/60">
                          المحامي الحاضر: {h.lawyer}
                        </span>
                      )}
                    </div>
                    <p className="font-bold text-slate-900">{h.decision}</p>
                    {h.notes && <p className="text-slate-600 text-[11px]">{h.notes}</p>}
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer Actions */}
        <div className="bg-slate-100 px-6 py-4 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopySummary}
              className="px-3 py-2 bg-white hover:bg-slate-200 text-slate-700 border border-slate-300 rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'تم نسخ الملخص' : 'نسخ ملخص الدعوى'}</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onClose();
                onPostpone(caseItem);
              }}
              className="px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer shadow-sm"
            >
              <ArrowRightLeft className="w-3.5 h-3.5" />
              <span>إثبات قرار / تأجيل الجلسة</span>
            </button>

            <button
              onClick={() => {
                onClose();
                onEdit(caseItem);
              }}
              className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer shadow-sm"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>تعديل البيانات</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
