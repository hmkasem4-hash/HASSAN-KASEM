import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  Plus, 
  Search, 
  Scale, 
  Building2, 
  Calendar, 
  Clock, 
  AlertTriangle, 
  CheckCircle2, 
  Layers, 
  FileText, 
  Sparkles,
  Download,
  Upload
} from 'lucide-react';
import confetti from 'canvas-confetti';

import { CourtCase, CourtType, ViewMode, DateFilterType, PreparationChecklistItem } from './types';
import { INITIAL_CASES } from './data/initialCases';
import { 
  isWithin24Hours, 
  isToday, 
  isTomorrow, 
  getTodayString, 
  addDaysToDate,
  formatArabicDate
} from './utils/dateUtils';
import { 
  playAlertChime, 
  requestNotificationPermission, 
  sendDesktopNotification 
} from './utils/audioAlert';

import { Navbar } from './components/Navbar';
import { AlertsBanner } from './components/AlertsBanner';
import { StatsOverview } from './components/StatsOverview';
import { CourtFilterTabs } from './components/CourtFilterTabs';
import { CaseCard } from './components/CaseCard';
import { CaseTableView } from './components/CaseTableView';
import { CaseTimelineView } from './components/CaseTimelineView';
import { CalendarMonthView } from './components/CalendarMonthView';
import { CaseModal } from './components/CaseModal';
import { PostponeModal } from './components/PostponeModal';
import { CaseDetailsModal } from './components/CaseDetailsModal';
import { CourtRollPrintModal } from './components/CourtRollPrintModal';

const STORAGE_KEY = 'court_hearings_cases_v2';
const SOUND_KEY = 'court_sound_enabled';

export default function App() {
  // Load saved cases from localStorage or fallback to realistic initial cases
  const [cases, setCases] = useState<CourtCase[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.warn('Could not read saved cases:', e);
    }
    return INITIAL_CASES;
  });

  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => {
    const saved = localStorage.getItem(SOUND_KEY);
    return saved !== null ? saved === 'true' : true;
  });

  const [hasNotificationPermission, setHasNotificationPermission] = useState<boolean>(() => {
    return typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted';
  });

  // Filter & View State
  const [selectedCourt, setSelectedCourt] = useState<string>('all');
  const [selectedDateFilter, setSelectedDateFilter] = useState<DateFilterType>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [viewMode, setViewMode] = useState<ViewMode>('cards');

  // Modal State
  const [isCaseModalOpen, setIsCaseModalOpen] = useState(false);
  const [editingCase, setEditingCase] = useState<CourtCase | null>(null);
  const [detailsCase, setDetailsCase] = useState<CourtCase | null>(null);
  const [postponeTargetCase, setPostponeTargetCase] = useState<CourtCase | null>(null);
  const [isPrintRollOpen, setIsPrintRollOpen] = useState(false);
  const [presetModalDate, setPresetModalDate] = useState<string | null>(null);

  // Save cases to localStorage on changes
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(cases));
    } catch (e) {
      console.warn('Failed to save to localStorage:', e);
    }
  }, [cases]);

  // Save sound setting
  useEffect(() => {
    localStorage.setItem(SOUND_KEY, String(soundEnabled));
  }, [soundEnabled]);

  // Check 24-hour alerts & play gentle reminder upon startup if urgent cases exist
  const hasAlertedRef = useRef(false);
  useEffect(() => {
    const urgentCount = cases.filter(isWithin24Hours).length;
    if (urgentCount > 0 && soundEnabled && !hasAlertedRef.current) {
      playAlertChime();
      hasAlertedRef.current = true;
      if (hasNotificationPermission) {
        sendDesktopNotification(
          'تنبيه جلسات القضايا (أقل من 24 ساعة)',
          `لديك ${urgentCount} جلسات منعقدة خلال الـ 24 ساعة القادمة. يرجى مراجعة تجهيزات الرول.`
        );
      }
    }
  }, [cases, soundEnabled, hasNotificationPermission]);

  // Extract all unique courts for filters
  const allCourts = useMemo(() => {
    const defaultCourts = [
      'محكمة النقض',
      'محكمة الاستئناف',
      'المحكمة الابتدائية',
      'المحكمة الاقتصادية',
      'محكمة الأسرة',
      'مجلس الدولة / القضاء الإداري',
      'محكمة الجنايات',
      'محكمة الجنح',
      'المحكمة العمالية',
      'المحكمة التجارية',
    ];
    const caseCourts = cases.map((c) => c.court).filter(Boolean);
    return Array.from(new Set([...defaultCourts, ...caseCourts]));
  }, [cases]);

  // Urgent 24h cases list
  const urgent24hCases = useMemo(() => {
    return cases.filter(isWithin24Hours);
  }, [cases]);

  // Filtered cases list based on search, court, and date filter
  const filteredCases = useMemo(() => {
    return cases.filter((c) => {
      // 1. Search Query Filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchNumber = c.caseNumber.toLowerCase().includes(q);
        const matchYear = c.caseYear.toLowerCase().includes(q);
        const matchTitle = c.title.toLowerCase().includes(q);
        const matchClient = c.clientName.toLowerCase().includes(q);
        const matchOpponent = c.opponentName.toLowerCase().includes(q);
        const matchCircuit = c.circuit.toLowerCase().includes(q);
        const matchCourt = c.court.toLowerCase().includes(q);
        const matchLawyer = (c.assignedLawyer || '').toLowerCase().includes(q);
        const matchDemands = (c.demands || '').toLowerCase().includes(q);

        if (!(matchNumber || matchYear || matchTitle || matchClient || matchOpponent || matchCircuit || matchCourt || matchLawyer || matchDemands)) {
          return false;
        }
      }

      // 2. Court Filter
      if (selectedCourt !== 'all' && c.court !== selectedCourt) {
        return false;
      }

      // 3. Date Filter
      if (selectedDateFilter === '24h') {
        return isWithin24Hours(c);
      }
      if (selectedDateFilter === 'today') {
        return isToday(c.sessionDate);
      }
      if (selectedDateFilter === 'tomorrow') {
        return isTomorrow(c.sessionDate);
      }
      if (selectedDateFilter === 'this_week') {
        const todayStr = getTodayString();
        const next7Days = addDaysToDate(todayStr, 7);
        return c.sessionDate >= todayStr && c.sessionDate <= next7Days;
      }
      if (selectedDateFilter === 'past') {
        return c.status === 'judged' || c.status === 'struck_off';
      }

      return true;
    });
  }, [cases, searchQuery, selectedCourt, selectedDateFilter]);

  // Calculate court case counts
  const courtCounts = useMemo(() => {
    const counts: Record<string, number> = { all: cases.length };
    cases.forEach((c) => {
      counts[c.court] = (counts[c.court] || 0) + 1;
    });
    return counts;
  }, [cases]);

  // Calculate date filter counts
  const dateFilterCounts = useMemo(() => {
    const todayStr = getTodayString();
    const next7Days = addDaysToDate(todayStr, 7);

    return {
      all: cases.length,
      '24h': cases.filter(isWithin24Hours).length,
      today: cases.filter((c) => isToday(c.sessionDate) && c.status !== 'judged').length,
      tomorrow: cases.filter((c) => isTomorrow(c.sessionDate) && c.status !== 'judged').length,
      this_week: cases.filter((c) => c.sessionDate >= todayStr && c.sessionDate <= next7Days && c.status !== 'judged').length,
      this_month: cases.length,
      past: cases.filter((c) => c.status === 'judged' || c.status === 'struck_off').length,
      custom: 0,
    };
  }, [cases]);

  // Handlers for Case CRUD
  const handleAddNewCase = (customDate?: string) => {
    setEditingCase(null);
    setPresetModalDate(customDate || null);
    setIsCaseModalOpen(true);
  };

  const handleEditCase = (c: CourtCase) => {
    setEditingCase(c);
    setPresetModalDate(null);
    setIsCaseModalOpen(true);
  };

  const handleDeleteCase = (id: string) => {
    if (window.confirm('هل أنت متأكد من حذف هذه القضية وجلساتها نهائياً؟')) {
      setCases((prev) => prev.filter((c) => c.id !== id));
      if (detailsCase?.id === id) setDetailsCase(null);
    }
  };

  const handleSaveCase = (caseData: Partial<CourtCase>) => {
    const now = new Date().toISOString();
    if (editingCase) {
      // Update
      setCases((prev) =>
        prev.map((c) =>
          c.id === editingCase.id
            ? ({ ...c, ...caseData, updatedAt: now } as CourtCase)
            : c
        )
      );
      if (detailsCase?.id === editingCase.id) {
        setDetailsCase((prev) => prev ? ({ ...prev, ...caseData, updatedAt: now } as CourtCase) : null);
      }
    } else {
      // Create new
      const newCase: CourtCase = {
        id: `case-${Date.now()}`,
        caseNumber: caseData.caseNumber || '',
        caseYear: caseData.caseYear || new Date().getFullYear().toString(),
        court: caseData.court || 'المحكمة الابتدائية',
        circuit: caseData.circuit || 'الدائرة الأولى',
        judge: caseData.judge || '',
        title: caseData.title || '',
        clientName: caseData.clientName || '',
        clientRole: caseData.clientRole || 'مدعي',
        clientPhone: caseData.clientPhone || '',
        opponentName: caseData.opponentName || '',
        opponentLawyer: caseData.opponentLawyer || '',
        assignedLawyer: caseData.assignedLawyer || '',
        sessionDate: caseData.sessionDate || getTodayString(),
        sessionTime: caseData.sessionTime || '09:30',
        sessionStage: caseData.sessionStage || 'مرافعة',
        status: caseData.status || 'active',
        previousDecision: caseData.previousDecision || '',
        demands: caseData.demands || '',
        notes: caseData.notes || '',
        checklist: caseData.checklist || [],
        remind24h: caseData.remind24h ?? true,
        history: [],
        createdAt: now,
        updatedAt: now,
      };

      setCases((prev) => [newCase, ...prev]);
    }
  };

  // Postpone / Log Decision handler
  const handlePostponeSubmit = (
    caseId: string,
    decision: string,
    nextDate: string,
    nextTime: string,
    nextDemands: string,
    reason?: string,
    nextLawyer?: string
  ) => {
    const now = new Date().toISOString();

    setCases((prev) =>
      prev.map((c) => {
        if (c.id === caseId) {
          const historyEntry = {
            id: `hist-${Date.now()}`,
            date: c.sessionDate,
            decision: decision,
            lawyer: c.assignedLawyer || '',
            reason: reason || '',
            notes: c.demands || '',
            createdAt: now,
          };

          const isJudged = decision.includes('حكمت المحكمة') || decision.includes('انقضاء') || decision.includes('رفض الدعوى');

          return {
            ...c,
            previousDecision: decision,
            sessionDate: nextDate,
            sessionTime: nextTime || c.sessionTime,
            demands: nextDemands,
            assignedLawyer: nextLawyer !== undefined && nextLawyer !== '' ? nextLawyer : c.assignedLawyer,
            status: isJudged ? 'judged' : 'postponed',
            history: [historyEntry, ...(c.history || [])],
            updatedAt: now,
          };
        }
        return c;
      })
    );

    // If judgment achieved, trigger celebration
    if (decision.includes('حكمت المحكمة') || decision.includes('لصالحنا')) {
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 },
      });
    }
  };

  // Quick Next Session Scheduler from Case Details
  const handleUpdateNextSession = (
    caseId: string,
    data: {
      nextDate: string;
      nextTime: string;
      nextDemands?: string;
      decisionNote?: string;
      assignedLawyer?: string;
    }
  ) => {
    const now = new Date().toISOString();

    setCases((prev) =>
      prev.map((c) => {
        if (c.id === caseId) {
          const historyEntry = {
            id: `hist-${Date.now()}`,
            date: c.sessionDate,
            decision: data.decisionNote || `تأجيل وتحديد موعد الجلسة القادمة ليوم ${formatArabicDate(data.nextDate)}`,
            lawyer: c.assignedLawyer || '',
            reason: data.decisionNote || '',
            notes: c.demands || '',
            createdAt: now,
          };

          return {
            ...c,
            previousDecision: data.decisionNote || c.previousDecision,
            sessionDate: data.nextDate,
            sessionTime: data.nextTime || c.sessionTime,
            demands: data.nextDemands !== undefined && data.nextDemands.trim() !== '' ? data.nextDemands : c.demands,
            assignedLawyer:
              data.assignedLawyer !== undefined && data.assignedLawyer.trim() !== ''
                ? data.assignedLawyer
                : c.assignedLawyer,
            status: 'postponed',
            history: [historyEntry, ...(c.history || [])],
            updatedAt: now,
          };
        }
        return c;
      })
    );
  };

  // Checklist item toggle
  const handleToggleChecklist = (caseId: string, itemId: string) => {
    setCases((prev) =>
      prev.map((c) => {
        if (c.id === caseId) {
          const updatedChecklist = c.checklist.map((item) =>
            item.id === itemId ? { ...item, completed: !item.completed } : item
          );
          return { ...c, checklist: updatedChecklist };
        }
        return c;
      })
    );

    if (detailsCase && detailsCase.id === caseId) {
      setDetailsCase((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          checklist: prev.checklist.map((item) =>
            item.id === itemId ? { ...item, completed: !item.completed } : item
          ),
        };
      });
    }
  };

  // Add item to checklist
  const handleAddChecklistItem = (caseId: string, text: string) => {
    const newItem: PreparationChecklistItem = {
      id: `chk-${Date.now()}`,
      text,
      completed: false,
    };

    setCases((prev) =>
      prev.map((c) => {
        if (c.id === caseId) {
          return { ...c, checklist: [...c.checklist, newItem] };
        }
        return c;
      })
    );

    if (detailsCase && detailsCase.id === caseId) {
      setDetailsCase((prev) => {
        if (!prev) return null;
        return { ...prev, checklist: [...prev.checklist, newItem] };
      });
    }
  };

  // Sound toggle
  const handleToggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    if (next) playAlertChime();
  };

  // Request browser notification permissions
  const handleRequestNotifications = async () => {
    const granted = await requestNotificationPermission();
    setHasNotificationPermission(granted);
    if (granted) {
      sendDesktopNotification('تم تفعيل التنبيهات الذكية', 'ستصلك إشعارات قبل مواعيد جلسات المحاكم بـ 24 ساعة.');
    }
  };

  // Export JSON Backup
  const handleExportData = () => {
    const dataStr = JSON.stringify(cases, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `قضايا_وجلسات_المحاكم_${getTodayString()}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Import JSON Backup
  const handleImportData = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const imported = JSON.parse(event.target?.result as string);
        if (Array.isArray(imported)) {
          setCases(imported);
          alert(`تم استيراد ${imported.length} قضية بنجاح!`);
        } else {
          alert('الملف غير متطابق مع نسق بيانات القضايا.');
        }
      } catch (err) {
        alert('حدث خطأ أثناء قراءة ملف النسخة الاحتياطية.');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-900 font-sans flex flex-col">
      
      {/* Top Navbar */}
      <Navbar
        urgentCount={urgent24hCases.length}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onAddNewCase={() => handleAddNewCase()}
        onOpenPrintRoll={() => setIsPrintRollOpen(true)}
        onToggleUrgentPanel={() => {
          setSelectedDateFilter('24h');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        viewMode={viewMode}
        onViewModeChange={setViewMode}
        soundEnabled={soundEnabled}
        onToggleSound={handleToggleSound}
        onRequestNotifications={handleRequestNotifications}
        hasNotificationPermission={hasNotificationPermission}
        onExportData={handleExportData}
        onImportData={handleImportData}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        
        {/* 24-Hour Urgent Alerts Accordion Banner */}
        <AlertsBanner
          urgentCases={urgent24hCases}
          onOpenCaseDetails={(c) => setDetailsCase(c)}
          onPostponeCase={(c) => setPostponeTargetCase(c)}
          onToggleChecklist={handleToggleChecklist}
        />

        {/* Stats Metrics Overview */}
        <StatsOverview
          cases={cases}
          onSelectFilter={(filter) => setSelectedDateFilter(filter)}
        />

        {/* Filters & View Switcher */}
        <CourtFilterTabs
          selectedCourt={selectedCourt}
          onSelectCourt={setSelectedCourt}
          courtCounts={courtCounts}
          selectedDateFilter={selectedDateFilter}
          onSelectDateFilter={setSelectedDateFilter}
          dateFilterCounts={dateFilterCounts}
          viewMode={viewMode}
          onViewModeChange={setViewMode}
          allCourts={allCourts}
        />

        {/* Views Rendering */}
        {viewMode === 'cards' && (
          <div>
            {filteredCases.length === 0 ? (
              <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center shadow-xs">
                <div className="w-16 h-16 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Scale className="w-8 h-8" />
                </div>
                <h3 className="text-base sm:text-lg font-bold text-slate-800 mb-1">
                  لا توجد قضايا أو جلسات مطابقة
                </h3>
                <p className="text-xs sm:text-sm text-slate-500 max-w-md mx-auto mb-5">
                  جرب تغيير خيارات التصفية أو البحث، أو أضف جلسة جديدة برول اليوم.
                </p>
                <button
                  onClick={() => handleAddNewCase()}
                  className="px-5 py-2.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-extrabold rounded-xl text-xs sm:text-sm shadow-md transition cursor-pointer"
                >
                  + إضافة جلسة جديدة الآن
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                {filteredCases.map((c) => (
                  <CaseCard
                    key={c.id}
                    caseItem={c}
                    onOpenDetails={(item) => setDetailsCase(item)}
                    onEdit={(item) => handleEditCase(item)}
                    onDelete={handleDeleteCase}
                    onPostpone={(item) => setPostponeTargetCase(item)}
                    onToggleChecklist={handleToggleChecklist}
                  />
                ))}
              </div>
            )}
          </div>
        )}

        {viewMode === 'table' && (
          <CaseTableView
            cases={filteredCases}
            onOpenDetails={(c) => setDetailsCase(c)}
            onEdit={(c) => handleEditCase(c)}
            onDelete={handleDeleteCase}
            onPostpone={(c) => setPostponeTargetCase(c)}
          />
        )}

        {viewMode === 'timeline' && (
          <CaseTimelineView
            cases={filteredCases}
            onOpenDetails={(c) => setDetailsCase(c)}
            onPostpone={(c) => setPostponeTargetCase(c)}
          />
        )}

        {viewMode === 'calendar' && (
          <CalendarMonthView
            cases={cases}
            onOpenDetails={(c) => setDetailsCase(c)}
            onPostpone={(c) => setPostponeTargetCase(c)}
            onAddNewCaseOnDate={(dateStr) => handleAddNewCase(dateStr)}
          />
        )}

      </main>

      {/* Case Create / Edit Modal */}
      <CaseModal
        isOpen={isCaseModalOpen}
        onClose={() => {
          setIsCaseModalOpen(false);
          setEditingCase(null);
          setPresetModalDate(null);
        }}
        onSave={handleSaveCase}
        initialData={
          editingCase || (presetModalDate ? ({ sessionDate: presetModalDate } as any) : null)
        }
        allCourts={allCourts}
      />

      {/* Postpone Session / Log Decision Modal */}
      <PostponeModal
        isOpen={!!postponeTargetCase}
        onClose={() => setPostponeTargetCase(null)}
        caseItem={postponeTargetCase}
        onPostponeSubmit={handlePostponeSubmit}
      />

      {/* Full Case Details Dossier Modal */}
      <CaseDetailsModal
        isOpen={!!detailsCase}
        onClose={() => setDetailsCase(null)}
        caseItem={detailsCase ? (cases.find((c) => c.id === detailsCase.id) || detailsCase) : null}
        onEdit={(c) => handleEditCase(c)}
        onPostpone={(c) => setPostponeTargetCase(c)}
        onUpdateNextSession={handleUpdateNextSession}
        onToggleChecklist={handleToggleChecklist}
        onAddChecklistItem={handleAddChecklistItem}
      />

      {/* Printable Court Roll Sheet Modal */}
      <CourtRollPrintModal
        isOpen={isPrintRollOpen}
        onClose={() => setIsPrintRollOpen(false)}
        cases={cases}
        allCourts={allCourts}
      />

      {/* Footer (No Print) */}
      <footer className="bg-slate-900 border-t border-slate-800 text-slate-400 py-6 text-xs text-center no-print mt-auto">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-slate-300 font-bold">
            <Scale className="w-4 h-4 text-amber-500" />
            <span>نظام إدارة ومتابعة جلسات المحاكم ورول القضايا</span>
          </div>
          <p className="text-slate-400">
            تنبيهات ذكية قبل 24 ساعة • تصنيف شامل حسب المحاكم • سجل القرارات التاريخية
          </p>
        </div>
      </footer>

    </div>
  );
}
